/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.mycompany.hafta9demo;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author arisoy
 */
public class Hafta9Demo {

    /**
     * satır ve sütunlara rastgele 0 ve 1 atayan bir program yazın
     *
     * rastgele array mesela şöyle olsun 0011 0011 1101 1010 en büyük satır
     * indeksi: 2 en büyük sütun indeksi: 2, 3
     */
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Satır sayısını giriniz:");

        int size = sc.nextInt();

        int[][] dizim = new int[size][size];

        for (int i = 0; i < dizim.length; i++) //size
        {
            for (int j = 0; j < dizim[i].length; j++) //size
            {

                dizim[i][j] = (int) (Math.random()*2);

            }
        }

        ArrayList<Integer> satir = new ArrayList<>();

        ArrayList<Integer> sutun = new ArrayList<>();

        for (int i = 0; i < dizim.length; i++) {
            int sum = 0;

            for (int j = 0; j < dizim[i].length; j++) {

                sum += dizim[i][j];

            }

            satir.add(i,sum);
        }

        for (int i = 0; i < dizim.length; i++) {
            int sutuntoplam = 0;
            for (int j = 0; j < dizim[i].length; j++) {
                sutuntoplam += dizim[j][i];

            }

            sutun.add(i,sutuntoplam);
        }
        
        
        Integer maxsatir=maxDegerBul(satir);
        
        Integer maxsutun=maxDegerBul(sutun);
        
        
        //dizimi göstermek için
        for (int i = 0; i < dizim.length; i++) 
        {
            for (int j = 0; j < dizim[i].length; j++)
            {
                
                System.out.print(dizim[i][j]);
            }
            System.out.println();
        }
        
        /*
        System.out.println("en büyük satırın bulunduğu indeks: ");
        
        for(Integer i: satir)
        {
            if (i.equals(maxsatir)) 
            {
                System.out.print(satir.indexOf(i));
                
            }        
        
        }
        
        
        System.out.println("\n en büyük sütunun bulunduğu indeks:");
        
        for (Integer a: sutun) {
            if (a.equals(maxsutun)) 
            {
                System.out.print(sutun.indexOf(a));
            }
            
        }
        
       
*/
         System.out.println("satır toplamları:"+satir);
         System.out.println("sütun toplamları:"+sutun);
         System.out.println("en büyük satırın bulunduğu indeks: "+maxsatir.toString());
         System.out.println("en büyük sütunun bulunduğu indeks:"+maxsutun.toString());

    }


    public static Integer maxDegerBul(ArrayList<Integer> listem) {

        Integer maxdeger = listem.get(0);

        for (Integer i : listem) {
            maxdeger = Math.max(i, maxdeger);
            

        }

        //return maxdeger;
        return listem.indexOf(maxdeger);

    }
}
