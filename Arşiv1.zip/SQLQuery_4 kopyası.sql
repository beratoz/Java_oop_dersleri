--A)where den sonra gelen subqueryler

--2300 konumda bulunan tüm çalışanları bulunuz
use sample

SELECT e.first_name,e.last_name,e.department_id,e.job_id,e.salary
from
employees e
where e.department_id IN(
select d.department_id
from
departments  d
where d.location_id=2300
)


---2300 lokasyonunda bulunmayan tüm çalışanları bulmak için:

SELECT e.first_name,e.last_name,e.department_id,e.job_id,e.salary
from
employees e
where e.department_id NOT IN(
select d.department_id
from
departments  d
where d.location_id=2300
)

---Aşağıdaki örnek en yüksek maaşı alan çalışanları göstermektedir:
select e.employee_id,e.first_name,e.last_name,e.department_id,e.salary
from
employees e
where e.salary=(
    select max(salary)
    from employees
)

--Aşağıdaki ifade, maaşları tüm çalışanların ortalama maaşından yüksek olan tüm çalışanları göstermektedir:
SELECT e.employee_id,e.first_name,e.last_name,e.department_id,e.salary
from
employees e
where e.salary > (

    select avg(salary)
    from employees
)

--EXISTS operatörü, alt sorgudan döndürülen satırların varlığını kontrol eder. 
--Alt sorgu herhangi bir satır içeriyorsa true değerini döndürür. 
--Aksi takdirde false değerini döndürür.
--NOT EXISTS operatörü EXISTS operatörünün tersidir.

--maaşı 10.000'den fazla olan en az bir çalışanı olan tüm departmanları bulunuz

SELECT 
    department_name
FROM
    departments d
WHERE
    EXISTS( SELECT 
            1
        FROM
            employees e
        WHERE
            salary > 10000    AND e.department_id = d.department_id)
ORDER BY department_name




--maaşı 10.000'in üzerinde çalışanı olmayan tüm departmanları bulun
SELECT 
    department_name
FROM
    departments d
WHERE
   Not EXISTS( SELECT 
            1
        FROM
            employees e
        WHERE
            salary > 10000   AND e.department_id = d.department_id )
ORDER BY department_name


--B)from dan sonra gelen subqueryler
--Kullanımı
/*

SELECT 
    *
FROM
    (subquery) AS table_name

    */


--Mesela departmenların ortalama maşlarının ortalmasını listeleyelim

SELECT AVG(average_salary)
from
(
SELECT AVG(salary) as average_salary,employees.department_id
From
employees
GROUP by department_id
) average_average_salary

--C)SQL Subquery in the SELECT clause --22.05.2024 de her iki şubeye ver

SELECT 
    employee_id,
    first_name,
    last_name,
    salary,
    (SELECT  AVG(salary) FROM  employees) average_salary,
    
    salary - (SELECT AVG(salary)  FROM employees) difference
FROM
    employees
ORDER BY first_name , last_name