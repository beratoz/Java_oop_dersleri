use sirket

--join ile mesela personel, proje ve gorevlendirme tablolarını birleştiricez diyelim 

select pr.ad,pr.soyad,pr.personel_no,pr.unvan_no,gr.proje_no,
pj.proje_ad,pj.baslama_tarihi,pj.planlanan_bitis_tarihi
from
personel pr
JOIN gorevlendirme gr
ON pr.personel_no=gr.personel_no
JOIN proje pj
on pj.proje_no=gr.proje_no


--1. tip subquery (where den sonra alt sorgu)

-----Aşağıdaki örnek en yüksek maaşı alan çalışanları göstermektedir
use sample

SELECT e.first_name,e.last_name,e.employee_id,e.salary,e.phone_number
from
employees e
 WHERE
 e.salary=
(
SELECT max(salary)
from employees
)



--Aşağıdaki ifade, maaşları tüm çalışanların 
--ortalama maaşından yüksek olan tüm çalışanları göstermektedir:


SELECT e.first_name,e.last_name,
e.phone_number,e.salary,e.employee_id
from
employees e
where e.salary >
(
SELECT avg(salary)
from employees
)

----2300 lokasyonunda bulunan tüm çalışanları listeleyin

SELECT e.first_name,e.last_name,e.employee_id,
e.phone_number,e.department_id,e.salary
from
employees e
where
e.department_id IN
(
SELECT department_id
from
departments 
WHERE location_id=2300
)

SELECT e.first_name,e.last_name,e.employee_id,
e.phone_number,e.department_id,e.salary
from
employees e
where
e.department_id not IN
(
SELECT department_id
from
departments 
WHERE location_id=2300
)


--maaşı 10.000'den fazla olan en az bir çalışanı 
--olan tüm departmanları bulunuz



select d.department_name
from
departments d
WHERE
Exists(
SELECT
1
from
employees e
WHERE
e.salary>10000 and e.department_id= d.department_id
)


select d.department_name
from
departments d
WHERE
not Exists(
SELECT
1
from
employees e
WHERE
e.salary>10000 and e.department_id= d.department_id
)

use sanatgalerisi

--1) Ortalamanın üzerinde fiyatlı tabloları listelemek istiyoruz

SELECT p.id,p.name
from
paintings p
where p.listed_price>
(SELECT avg(listed_price)
from
paintings) 

--2)Galerimizden resim satın alan tüm koleksiyoncuları 
--listelemek istediğimizi varsayalım.

SELECT c.first_name,c.last_name
from
collectors c
where c.id IN 
(

SELECT s.collector_id
from
sales s 
)


--yada böyle

SELECT distinct c.id,c.first_name,c.last_name
from
sales s
JOIN collectors c
on s.collector_id=c.id



--B)from dan sonra gelen subqueryler
--Kullanımı
/*

SELECT 
    *
FROM
    (subquery) AS table_name

    */


use sample

----Mesela departmenların ortalama maşlarının 
--ortalmasını listeleyelim

SELECT avg(ortalama)
from
(
    SELECT avg(e.salary) as ortalama,department_id
    from
    employees e
    GROUP by department_id
) 
as ortalamanın_ortalması


--C)SQL Subquery in the SELECT (3.tip alt sorgu)
use sample

SELECT e.employee_id,e.first_name,e.last_name,e.salary,

(select avg(salary) from employees )as ortalama_maas,

e.salary-(select avg(salary) from employees)as  maas_fark
from
employees e
ORDER by e.first_name,e.last_name 


use sanatgalerisi

SELECT
  first_name,
  last_name,
  (
    SELECT count(*) AS paintings
    FROM sales
    WHERE collectors.id = sales.collector_id
  )
FROM collectors
