create database sanatgalerisi
go

use sanatgalerisi

CREATE table paintings(
    id int not NULL,
    name VARCHAR(50) not NULL,
    artist_id int not null,
    listed_price money
)

go

insert into paintings
values (11,	'Miracle',	1,	300.00),
(12,	'Sunshine',	1,	700.00),
(13	,'Pretty woman',	2 ,2800.00),
(14,	'Handsome man'	,2,	2300.00),
(15	,'Barbie',	3,	250.00),
(16	,'Cool painting',	3,	5000.00),
(17,	'Black square'	,3,	50.00),
(18,	'Mountains'	,4,	1300.00)

GO
CREATE table artists(
    id	int not NULL,	
    first_name VARCHAR(50) not NULL,
    last_name VARCHAR(50) not NULL
)

GO
insert into artists
VALUES (1	,'Thomas',	'Black'),
(2,	'Kate',	'Smith'),
(3,	'Natali',	'Wein'),
(4,	'Francesco'	,'Benelli')

GO

CREATE table collectors(
    id	int not NULL,	
    first_name VARCHAR(50) not NULL,
    last_name VARCHAR(50) not NULL
)

go
insert  into collectors
values (101	,'Brandon',	'Cooper'),
(102,	'Laura'	,'Fisher'),
(103,	'Christina',	'Buffet'),
(104,	'Steve',	'Stevenson')


CREATE table sales(
    id	int not NULL,	
    date DATETIME ,
    painting_id	int not NULL,
    artist_id	int not NULL,
    collector_id int not NULL,	
    sales_price money
)

GO
insert into sales
VALUES (1001,	'2021-11-01'	,13,	2,	104	,2500.00),
(1002,	'2021-11-10',	14,	2,	102	,2300.00),
(1003,	'2021-11-10',	11,	1,	102	,300.00),
(1004,	'2021-11-15'	,16	,3	,103,	4000.00),
(1005,	'2021-11-22',	15	,3	,103,	200.00),
(1006	,'2021-11-22',	17,	3	,103	,50.00)