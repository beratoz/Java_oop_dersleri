--1) Ortalamanın üzerinde fiyatlı tabloları listelemek istiyoruz
use sanatgalerisi

select * FROM
paintings p
where p.listed_price > (
    select avg(listed_price)
    from paintings
)


--2)Galerimizden resim satın alan tüm koleksiyoncuları listelemek istediğimizi varsayalım.

SELECT * from 
collectors c
where c.id IN(

    select s.collector_id
    from sales s 
)


--aynı şeyi verir
SELECT DISTINCT collectors.id,collectors.first_name, collectors.last_name
FROM collectors
JOIN sales
ON collectors.id = sales.collector_id;

--3) Diyelim ki galerimizde en az bir tablo satan her sanatçının toplam satış miktarını görmek istiyoruz.

SELECT
  ar.first_name,
  ar.last_name,
  artist_sales.sales
  
FROM artists ar
JOIN (
    SELECT artist_id, SUM(sales_price) AS sales
    FROM sales
    GROUP BY artist_id
    Having COUNT(artist_id)>=1
  ) AS artist_sales
ON ar.id = artist_sales.artist_id

--4)Her koleksiyoncu için galerimizden satın alınan tablo sayısını hesaplamak istiyoruz.
SELECT
  first_name,
  last_name,
  (
    SELECT count(*) AS paintings
    FROM sales
    WHERE collectors.id = sales.collector_id
  )
FROM collectors

--yada böyle

SELECT COUNT(*),first_name,last_name
from sales s, collectors c
where s.collector_id=c.id
GROUP by first_name,last_name

--yada böyle
SELECT COUNT(*),first_name,last_name
FROM sales s 
JOIN collectors c on s.collector_id=c.id
GROUP by first_name,last_name

--5)galerimizde satışı sıfır olan sanatçıların ad ve soyadlarını göstermek istiyoruz.
SELECT first_name, last_name
FROM artists
WHERE not EXISTS (
  SELECT *
  FROM sales
  WHERE sales.artist_id = artists.id
)

use eticaret

-- müşteri kimliğini maksimum olan müşterinin 
--adını listeleyin

SELECT cus.CustomerName
from
Customers cus
where cus.CustomerID =(
    select max(CustomerID)
    from Customers
)

---- Müşteriler tablosunda minimum posta koduna sahip müşterinin listeleyin
SELECT cus.CustomerName
from
Customers cus

WHERE cus.PostalCode=(
    select MIN(PostalCode)
    from
    Customers
)

---- sipariş verilen ürünleri seçin
SELECT p.ProductName
FROM Products p
WHERE p.ProductID IN (
  SELECT ProductID
  FROM OrderDetails
)
--orderdetaşl deki productid fk yanibir sürü ondan var o yüzden in kullandık




