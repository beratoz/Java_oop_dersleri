use sirket

--join ile mesela personel, proje ve gorevlendirme tablolarını birleştiricez diyelim 
SELECT pr.ad,pr.soyad,pr.maas,pj.proje_no,pj.proje_ad,pj.baslama_tarihi,pj.planlanan_bitis_tarihi
from personel pr
join gorevlendirme gr
on pr.personel_no=gr.personel_no
join proje pj
on pj.proje_no=gr.proje_no

--eğer daha fazla tablo da birleştirmek istersek bu şekilde join deyip (left join,right join de olabilir) ekelyerek gideriz birleştirilecek olan tabloyu

---------------------------- WHERE 'den SONRAKİ ALT SORGULAR------------------------

